Before using this example, install the USB driver first if the driver is not installed (by extract USBDRV.zip).see "PC Software USB Driver Install Guide" for installation instructions,.


The introduction of VI

bulk read.vi    read data from usb device

bulk write.vi   write data to usb device

close usb.vi    After data reception, close the device, release handle

open usb.vi     open usb device

find devices.vi  to find usb device used VID,PID,return the number of device 

get device CstrSerialNumber.vi  get serial number form the usb device

simple case.vi is a example for receive waveform data from the oscilloscope.the received data saved to file whice can be used in PC Software and the file format as "Oscilloscope PC Guidance Manual.doc"(please contact us to get newest ver)

simple manipulate.vi is a example for manipulate machine 